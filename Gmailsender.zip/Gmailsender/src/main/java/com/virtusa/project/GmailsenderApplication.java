package com.virtusa.project;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ApplicationContext;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.context.ApplicationContext;

import com.virtusa.project.been.Mail;
import com.virtusa.project.services.mailInterface;
 
@SpringBootApplication
public class GmailsenderApplication {

	public static void main(String[] args) {
		//SpringApplication.run(GmailsenderApplication.class, args);
		 Mail mail = new Mail();
	        mail.setMailFrom("ramakrishna711999@gmail.com");
	        mail.setMailTo("padamati2000@gmail.com");
	        mail.setMailSubject("Spring Boot - Email Example");
	        mail.setMailContent("hii this krrish mail send is working");
	 
	        ApplicationContext ctx = SpringApplication.run(GmailsenderApplication.class, args);
	        mailInterface mailService = (mailInterface) ctx.getBean("mailService");
	        mailService.sendEmail(mail);
	}

}
