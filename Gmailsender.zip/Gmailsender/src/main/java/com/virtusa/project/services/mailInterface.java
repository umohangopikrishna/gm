package com.virtusa.project.services;

import com.virtusa.project.been.Mail;

public interface mailInterface {
public void sendEmail(Mail mail);

}
