package com.virtusa.project;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class GmailsenderApplicationTests {

	@Test
	void contextLoads() {
	}

}
